package cpsc411.Assign1.RestDB


open class RestDB {

    lateinit var sqlStmt : String

}