package cpsc411.Assign1.RestDB.Claim

import java.util.*

data class Claim (val id:UUID?, var title:String?, var date:String?, var isSolved:Boolean?)

fun main(){
    /*
    <Insert new. manual claim entry
    */
}